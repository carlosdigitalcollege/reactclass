import CardList  from './components/CardList/CardList';

const cardListInfo = [
  { title: 'Card 1', imageUrl: 'https://media.giphy.com/media/10SvWCbt1ytWCc/giphy.gif'},
  { title: 'Card 2', imageUrl: 'https://media.giphy.com/media/LwIyvaNcnzsD6/giphy.gif'},
  { title: 'Card 3', imageUrl: 'https://media.giphy.com/media/10SvWCbt1ytWCc/giphy.gif'},
  { title: 'Card 4', imageUrl: 'https://media.giphy.com/media/10SvWCbt1ytWCc/giphy.gif'},
]

const MeuApp = () => {
  return (
    <div className="App">
      <CardList cardListInfo={cardListInfo} /> 
    </div>
  );
}

export default MeuApp;
