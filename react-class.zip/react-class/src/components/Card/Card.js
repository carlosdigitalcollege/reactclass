import './Card.css'

const Card = ({ imageUrl, title }) => {
  const emptyImageUrl = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQbkqJWTEKCa0a3GqdFwc8b_Aefzd76gFTs4II-awU&s'

  return ( 
    <div className="card 1">
      <div className="card_image">
        <img src={imageUrl || emptyImageUrl } />
      </div>
      
      <div className="card_title title-white">
        <p>{title}</p>
      </div>
    </div>
  )
}

export default Card