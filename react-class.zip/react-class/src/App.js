import logo from './logo.svg';
import './App.css';

const ReactLogo = () => {
  return ( 
    <img
      src={logo}
      className="App-logo"
      alt="logo"
    />
  )
}

const Text = (props) => {
  return (
    <p>{props.children}</p>
  )
}

const Link = (props) => {
  return (
    <a
      className="App-link"
      href="https://reactjs.org"
      target="_blank"
      rel="noopener noreferrer"
    >
      {props.children || 'Veja a documentação!'}
    </a>
  )
}

const App = () => {
  return (
    <div className="App">
      <header className="App-header">
        <Link />
        <ReactLogo />
        <Text>
          Edit <code>src/App.js</code> and save to reload.
        </Text>
        <Link>
          <Text>
            Reload.
          </Text>
        </Link>
      </header>
    </div>
  );
}

export default App;
